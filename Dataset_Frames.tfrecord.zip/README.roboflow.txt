
Dataset 1 MA - v2 2020-12-31 7:50pm
==============================

This dataset was exported via roboflow.ai on December 31, 2020 at 6:51 PM GMT

It includes 172 images.
Elements are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 800x600 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip


